import open3d as o3d
import numpy as np
import open3d.visualization as visual

VOXEL_SIZE =  0.001

### Read original point cloud 
pcd = o3d.io.read_point_cloud("box.ply") 

### Down sample with voxel size 1mm 
pcd = pcd.voxel_down_sample(voxel_size = VOXEL_SIZE)
pcd, ind = pcd.remove_statistical_outlier(nb_neighbors=40, std_ratio=2.0) 

### Remove the non-Table objects 
points = np.asarray(pcd.points) 
points = points[points[:, 0] <=  0.30]
points = points[points[:, 0] >= -0.30]
pcd.points = o3d.utility.Vector3dVector(points)
# o3d.visualization.draw_geometries([pcd]) 

### Get table plane 
plane_model, inliers = pcd.segment_plane(distance_threshold=0.01, ransac_n=3, num_iterations=10000)
[a, b, c, d1] = plane_model
# print(f"Table Plane equation: {a:.2f}x + {b:.2f}y + {c:.2f}z + {d1:.3f} = 0")
table_pcd = pcd.select_by_index(inliers)
table_pcd.paint_uniform_color([1.0, 0, 0]) 
other_pcd = pcd.select_by_index(inliers, invert=True)

### Get box plane 
plane_model, inliers = other_pcd.segment_plane(distance_threshold=0.015, ransac_n=3, num_iterations=10000)
[a, b, c, d2] = plane_model
# print(f"Box Plane equation: {a:.2f}x + {b:.2f}y + {c:.2f}z + {d2:.3f} = 0")

### Calculate box height from 2 planes
depth = d1 - d2 
box_pcd = other_pcd.select_by_index(inliers)

### Pick up any box point plus depth 
points = np.asarray(box_pcd.points) 
points[-100, 2] -= depth
box_pcd.points = o3d.utility.Vector3dVector(points)
box_pcd.paint_uniform_color([0, 0, 1.0]) 

### Get box bounding box as box length, width & height 
bbox = box_pcd.get_axis_aligned_bounding_box() 
bbox.color = (0, 1, 0) 
bound = bbox.max_bound - bbox.min_bound
print(f"Width: {bound[0]*1000:.0f}mm, Length: {bound[1]*1000:.0f}mm, Height: {bound[2]*1000:.0f}mm") 

o3d.visualization.draw_geometries([pcd, bbox]) 
